window.dataCollect = {
    "songName": [
        "刘惜君 - 时光慢旅",
        "毛不易 - 呓语 (Live)"
    ],
    "songUrl": [
        "https://sharefs.yun.kugou.com/201910211547/d0c492219d6ec98482eaf70440a8b9e9/G164/M01/07/05/5A0DAF1abZeAb8eTADswN2WKufg944.mp3",
        "https://sharefs.yun.kugou.com/201910211549/dde93159df35bbf8b56ae51220dd8ab4/G162/M00/10/05/gpQEAFzL-7KAEcDEAEgdE5KhE9U388.mp3",
    ],
    "songPic": [
        [
            "https://i.loli.net/2019/10/21/z6dHtfyxVKYDmsr.jpg",
            "https://i.loli.net/2019/10/21/rTWUEkGmft4lqKD.jpg",
            "https://i.loli.net/2019/10/21/SaxOpJoWMgvhIHq.jpg",
            "https://i.loli.net/2019/10/21/EoixGjYTVrHBSKO.jpg",
            "https://i.loli.net/2019/10/21/squcbKgOPEH2FBf.jpg",
            "https://i.loli.net/2019/10/21/DuCx6TLQypoKEmA.jpg"
        ],
        [
            "https://i.loli.net/2019/10/21/nhdU7po2YezlmXR.jpg",
            "https://i.loli.net/2019/10/21/S2fRH56zpYluCsZ.jpg",
            "https://i.loli.net/2019/10/21/HTfVDNMobdRXCz9.jpg",
            "https://i.loli.net/2019/10/21/svZKzChxiwjdq3D.jpg",
            "https://i.loli.net/2019/10/21/L1MqambZSzt4IdB.jpg",
            "https://i.loli.net/2019/10/21/QM27nIf5ZXc6tG9.jpg"
        ]
    ],
    "lyricUrl": [
        "../source/lyric/刘惜君 - 时光慢旅.txt",
        "../source/lyric/毛不易 - 呓语 (Live).txt"
    ]
}