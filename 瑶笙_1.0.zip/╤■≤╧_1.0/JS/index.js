$(() => {
    let bg = document.querySelector(".imgs .list");
    let player = $(".operate .dir .player");
    let pause = $(".operate .dir .pause");
    let up = $(".operate .dir .up");
    let down = $(".operate .dir .down");
    let $main = $("#main");
    let audio = $("audio")[0];
    let $audio = $("audio");
    let song;
    let path;
    let lyric;
    window.currIndex = 0;
    window.timerBG;
    let allData = { songName, songUrl, songPic, lyricUrl } = dataCollect;

    // /** 歌曲数据解析 */
    // let dataAnalyse = (data)=>{
    //     var allData = {songName,songUrl,songPic,lyricUrl} = data;
    //     console.log(allData.songName);
    // }

    // dataAnalyse(dataCollect);



    /** 播放 */
    player.click(() => {
        player.addClass("hidden");
        pause.removeClass("hidden");
        audio.play();
    });
    /** 暂停 */
    pause.click(() => {
        player.removeClass("hidden");
        pause.addClass("hidden");
        audio.pause();
    });

    /** 当前歌曲 */
    let setSong = (currIndex) => {
        // 设置歌词
        $audio.attr("song", allData.songName[currIndex]);
        song = $audio.attr("song");
        // path = `../source/lyric/${song}.txt`;
        path = allData.lyricUrl[currIndex];
        lyric = new Lyric(path);
        //设置歌曲
        // $("audio").attr("src",`../source/music/${allData.songName[currIndex]}.mp3`);
        $audio.attr("src", allData.songUrl[currIndex]);
        // src="../source/music/刘惜君 - 时光慢旅.mp3"
    }

    /** 上一首 */
    up.click(() => {
        if (currIndex - 1 < 0) {
            currIndex = allData.songName.length - 1;
        } else {
            currIndex--;
        }
        // $audio.attr("autoplay","autoplay");
        audio.play();
        player.addClass("hidden");
        pause.removeClass("hidden");
        initAll();
    })

    /** 下一首 */
    down.click(() => {
        if (currIndex + 1 >= allData.songName.length) {
            currIndex = 0;
        } else {
            currIndex++;
        }
        // $audio.attr("autoplay","autoplay");
        audio.play();
        player.addClass("hidden");
        pause.removeClass("hidden");
        initAll();
    })



    /**
     * 设置背景轮播的方法
     * @param {*} currIndex 当前歌曲下标
     */
    let changeBG = (currIndex) => {
        $main.css("background-image", `url(${allData.songPic[currIndex][0]})`);
        let i = 1;
        // clearInterval(timerBG);
        timerBG = setInterval(() => {
            $main.css("background-image", `url(${allData.songPic[currIndex][i]})`);
            i = ++i > 5 ? 0 : i;
        }, 5000);
    }

    /**
     * 设置轮播图的方法
     * @param {*} currIndex 当前歌曲下标
     */
    let changeShow = (currIndex) => {
        let inner = `<li>
        <img src="${allData.songPic[currIndex][0]}" alt="">
    </li>
    <li>
        <img src="${allData.songPic[currIndex][1]}" alt="">
    </li>
    <li>
        <img src="${allData.songPic[currIndex][2]}" alt="">
    </li>
    <li>
        <img src="${allData.songPic[currIndex][3]}" alt="">
    </li>
    <li>
        <img src="${allData.songPic[currIndex][4]}" alt="">
    </li>
    <li>
        <img src="${allData.songPic[currIndex][5]}" alt="">
    </li>`;
        bg.innerHTML = inner;
    }
    let initAll = () => {
        setSong(currIndex);
        changeBG(currIndex);
        changeShow(currIndex);
        lyric.loadLyric();
        lyric.loadLyric();
    }
    initAll();
})